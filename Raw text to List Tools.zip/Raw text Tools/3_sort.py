# Define the input and output file names
input_file_name = "2_clean.txt"
capslock_file_name = "4_caps.txt"
lowercase_file_name = "4_lower.txt"
mixed_case_file_name = "4_mixed.txt"

# Open the input file for reading
with open(input_file_name, "r") as input_file:
    # Open the output files for writing
    with open(capslock_file_name, "w") as capslock_file, \
         open(lowercase_file_name, "w") as lowercase_file, \
         open(mixed_case_file_name, "w") as mixed_case_file:

        # Read each line from the input file
        for line in input_file:
            # Remove leading and trailing whitespaces
            line = line.strip()

            # Check if the line is all lowercase
            if line.islower():
                lowercase_file.write(line + "\n")
            # Check if the line is all uppercase
            elif line.isupper():
                capslock_file.write(line + "\n")
            # If it's not all lowercase or all uppercase, it's mixed case
            else:
                mixed_case_file.write(line + "\n")

print("File classification completed.")

