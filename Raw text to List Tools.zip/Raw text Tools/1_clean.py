import re

# Function to check if a line contains any special characters
def contains_special(line):
    return bool(re.search(r'[^a-zA-Z\'\s]', line))

# Function to check if a line contains any vowels
def contains_vowels(line):
    return bool(re.search(r'[aeiouwyAEIOUWY]', line))

# Function to check if a line contains any consonants
def contains_consonants(line):
    return bool(re.search(r'[bcdfghjklmnpqrstvxzBCDFGHJKLMNPQRSTVXZ]', line))

# Function to check if a line contains any digits
def contains_digits(line):
    return bool(re.search(r'[1234567890]', line))

# Function to process the input and generate the cleaned output
def clean_text(input_file, output_file):
    with open(input_file, 'r') as raw_file, open(output_file, 'w') as cleaned_file:
        # Create an empty list to store processed lines
        processed_lines = []

        for line in raw_file:
            # Remove leading/trailing whitespace and skip empty lines
            line = line.strip()
            if not line:
                continue

            # Replace spaces with line breaks
            line = line.replace(' ', '\n')

            # Append the processed line to the list
            processed_lines.extend(line.split('\n'))

        # After processing all lines, run checks and write to the output file
        cleaned_lines = []
        for line in processed_lines:
            # Check if the line contains at least one vowel and one consonant,
            # and it's not a single letter
            if len(line) > 1 and contains_vowels(line) and contains_consonants(line):
                if not contains_special(line):
                    if not contains_digits(line):
                        cleaned_lines.append(line)

        # Sort the cleaned lines alphabetically
        cleaned_lines.sort()

        # Write the sorted cleaned lines to the output file
        for line in cleaned_lines:
            cleaned_file.write(line + '\n')

# Input and output file names
input_file = '0_raw.txt'
output_file = '2_clean.txt'

# Call the clean_text function to process the files
clean_text(input_file, output_file)

print("Text cleaned and saved to '2_clean.txt' (sorted alphabetically)")

