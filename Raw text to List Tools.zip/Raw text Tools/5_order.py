import sys

def read_file(file_path):
    with open(file_path, 'r') as file:
        return [line.strip() for line in file]

def write_file(file_path, data):
    with open(file_path, 'w') as file:
        file.write("\n".join(data))

def sort_file(input_file, reference_file, output_file):
    # Read lines from both input files
    input_lines = read_file(input_file)
    
    # Read reference lines
    with open(reference_file, 'r') as ref_file:
        reference_lines = [line.strip() for line in ref_file.readlines()]

    # Create a dictionary to store the index of each line in the reference file
    reference_index = {line: i for i, line in enumerate(reference_lines)}

    # Sort the input lines based on their order in the reference file
    sorted_input_lines = sorted(input_lines, key=lambda x: reference_index.get(x, len(reference_lines)))

    # Find words that are not in the reference file
    missing_words = [line for line in input_lines if line not in reference_index]

    sorted_input_lines = [line for line in input_lines if line in reference_index]

    # Add "END_OF_REFERENCE" line and append the missing words alphabetically
    sorted_input_lines = sorted_input_lines +["END_OF_REFERENCE"] + sorted(missing_words)

    # Write the sorted lines to the output file
    write_file(output_file, sorted_input_lines)

if __name__ == "__main__":
    if len(sys.argv) != 1:
        print("Usage: python your_script.py")
        sys.exit(1)
    
    # Sort the input files
    sort_file("4_caps.txt", "reference.txt", "6_order_caps.txt")
    sort_file("4_lower.txt", "reference.txt", "6_order_lower.txt")
    sort_file("4_mixed.txt", "reference.txt", "6_order_mixed.txt")
    
    print("Sorted lines")

